export interface Profiles {
  id: number;
  firstname: string;
  lastname: string;
  sex: string;
  birthday: Date;
}

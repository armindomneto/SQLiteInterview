CREATE TABLE IF NOT EXISTS profiles_db(id INTEGER PRIMARY KEY AUTOINCREMENT,firstname TEXT,lastname TEXT,sex TEXT, birthday DATE);
-- INSERT or IGNORE INTO profiles_db VALUES (1, 'Armindo', 'Malafaia', 'Male', '1975-04-20T11:13:44.742-04:00');
-- INSERT or IGNORE INTO profiles_db VALUES (2, 'Francelina', 'Malafaia', 'Female', '1983-11-03T11:13:44.742-04:00');
-- INSERT or IGNORE INTO profiles_db VALUES (3, 'Roberto', 'Vieira', 'Male', '1986-11-01T11:13:44.742-04:00');
-- INSERT or IGNORE INTO profiles_db VALUES (4, 'John', 'Carter', 'Male', '1955-03-24T11:13:44.742-04:00');
